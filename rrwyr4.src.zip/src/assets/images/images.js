// images.js
const imagesObject = {
  sarahedo: {
    id: 'sarahedo',
    avatarURL: 'avataaars_SE.png',
  },
  tylermcginnis: {
    id: 'tylermcginnis',
    avatarURL: 'avataaars_TM.png',
  },
  johndoe: {
    id: 'johndoe',
    avatarURL: 'avataaars_JD.png',
  },
}

export default imagesObject
